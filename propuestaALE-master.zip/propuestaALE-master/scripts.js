var myFullpage = new fullpage('#fullpage', {});
AOS.init();
confetti.start();